import random

small_letters = "abcdefghijklmnopqrstuvwxyz"
capital_letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
diactric_letters = "ąęłńóśźżĄĘŁŃÓŚŹŻ"
numbers = "0123456789"
special_characters = "!@#$%^&*()_+"
avalible_characters = ["small_letters","small_letters", "small_letters", "capital_letters", "capital_letters", "capital_letters", "diactric_letters", "diactric_letters", "numbers", "numbers", "special_characters", "special_characters" ]
#nazwa funkcji: generate_password
#opis funkcji: funkcja generuje losowe hasło, ilość danego typu znaku np małe litery jest zgodna z wymaganiami
#parametry: brak
#zwracany typ i opis: zwraca string random_password czyli wygenerowane losowe hasło zgodnie z wymaganiami
#autor: 0000000000
def generate_password():
    random_password = ""
    for i in range(len(avalible_characters)):
        random_character_type = random.choice(avalible_characters)
        match random_character_type:
            case "small_letters":
                random_password += random.choice(small_letters)
            case "capital_letters":
                random_password += random.choice(capital_letters)
            case "diactric_letters":
                random_password += random.choice(diactric_letters)
            case "numbers":
                random_password += random.choice(numbers)
            case "special_characters":
                random_password += random.choice(special_characters)
        avalible_characters.remove(random_character_type)
    return random_password

for i in range(0,5):
    avalible_characters = ["small_letters","small_letters", "small_letters", "capital_letters", "capital_letters", "capital_letters", "diactric_letters", "diactric_letters", "numbers", "numbers", "special_characters", "special_characters" ]
    print(f"Hslo nr {i+1}: {generate_password()}")